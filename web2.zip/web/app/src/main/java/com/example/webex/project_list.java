package com.example.webex;

import static com.example.webex.md5.encrypt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.Callable;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.functions.Consumer;

public class project_list extends AppCompatActivity {
    private projectsTable projectHelper  = new projectsTable();

    private TextView textStatus;
    private TextView textTitle;
    private TextView textPart;
    private int idProject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_list);
        textStatus = (TextView) findViewById(R.id.status);
        textTitle = (TextView) findViewById(R.id.title);
        textPart= (TextView) findViewById(R.id.part);

        try {
            projectHelper.getProjects(
                    ()->{successDataOutput(projectHelper.getData()); return null;},
                    ()->{loginFailed(); return null;}
            );
        } catch (UnsupportedEncodingException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Button openProject = (Button) findViewById(R.id.openProject);
        openProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(project_list.this, project.class);
                intent1.putExtra("id", idProject);
                startActivity(intent1);
            }
        });

        Button openChat = (Button) findViewById(R.id.openChat);
        openChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(project_list.this, chat.class);
                startActivity(intent1);
            }
        });
    }


    private void successDataOutput(JSONArray data) throws JSONException {
        JSONObject ob  = data.getJSONObject(0);
        idProject = Integer.parseInt(ob.get("id").toString());
        textStatus.setText(ob.get("id_status").toString());
        textTitle.setText(ob.get("title").toString());
        textPart.setText(ob.get("part").toString());
    }
    private void loginFailed(){
        Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
    }
}