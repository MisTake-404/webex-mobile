package com.example.webex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class chat extends AppCompatActivity {
    private chatTable chatHelper  = new chatTable();
    private getUserId projectHelperUserId  = new getUserId();

    private TextView author;
    private TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        author = (TextView) findViewById(R.id.author);
        message = (TextView) findViewById(R.id.message);

        try {
            chatHelper.getProjects(
                    ()->{successDataOutput(chatHelper.getData()); return null;},
                    ()->{loginFailed(); return null;}
            );
        } catch (UnsupportedEncodingException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Button put = (Button) findViewById(R.id.put);
        put.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    private void successDataOutput(JSONArray data) throws JSONException {
        JSONObject ob  = data.getJSONObject(0);
        int id_user = Integer.parseInt(ob.get("id_user").toString());

        try {
            projectHelperUserId.getUser(id_user,
                    ()->{seccuessDataUserOutput(projectHelperUserId.getData()); return null;},
                    ()->{loginFailed(); return null;});
        } catch (UnsupportedEncodingException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        message.setText(ob.get("content").toString());
    }

    private void seccuessDataUserOutput(JSONArray dataUser) throws JSONException {
        JSONObject obUser  = dataUser.getJSONObject(0);
        author.setText(obUser.get("name").toString() + obUser.get("surname").toString());
    }
    private void loginFailed(){
        Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
    }
}