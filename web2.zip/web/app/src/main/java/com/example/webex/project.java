package com.example.webex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class project extends AppCompatActivity {
    private projectsTable projectHelper  = new projectsTable();

    private TextView textStatus;
    private TextView textTitle;
    private TextView textPart;
    private int idProject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);

        textStatus = (TextView) findViewById(R.id.status);
        textTitle = (TextView) findViewById(R.id.title);
        textPart= (TextView) findViewById(R.id.part);

        idProject = Integer.parseInt(getIntent().getStringExtra("id").toString());

        try {
            projectHelper.getProjects(
                    ()->{successDataOutput(projectHelper.getData()); return null;},
                    ()->{loginFailed(); return null;}
            );
        } catch (UnsupportedEncodingException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Button openChat = (Button) findViewById(R.id.openChat);
        openChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(project.this, chat.class);
                startActivity(intent1);
            }
        });
    }

    private void successDataOutput(JSONArray data) throws JSONException {
        JSONObject ob  = data.getJSONObject(0);
        textStatus.setText(ob.get("id_status").toString());
        textTitle.setText(ob.get("title").toString());
        textPart.setText(ob.get("part").toString());
    }
    private void loginFailed(){
        Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
    }
}